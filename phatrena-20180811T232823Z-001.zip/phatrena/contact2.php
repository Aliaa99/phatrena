    <!-- اتصل بنا -->    
<div class="contact margin-top">
    <div class="container transform">
       <h2 class="family">منتجات متشابهة</h2>
        <?php
        include 'product-part.php';
        ?>
        </div>
        <?php
        include 'carousle.php';
        ?>
</div>