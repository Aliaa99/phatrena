<?php
include 'header.php';
?>

<div class="main-header">
    <div class="phatrena-buy">
        <div class="products-head">
           <div>
                <h1 class="animated bounceInDown sizeless">الرئيسية</h1>
                <h5 class="animated bounceInDown sizemore">إتمام الشراء</h5>
           </div>
       </div>
    </div>
</div>

<div class="cart mt-5">
   <div class="container">
      <div class="row">
          <div class="col-lg-8">
            <form action=""class="mb-5">
                <div class="buy-form right">
                    <h6><span>1</span>يرجى تسجيل الدخول</h6>
                    <div class="row pr-3">
                        <div class="col-sm-6 ">
                        <div class="buy-head"><span>عميل جديد</span></div>
                        <div class="form-check">
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" name="optradio"><span class="block">الدفع كزائر</span>
                                        إتمام الشراء السريع بدون الحاجة لإنشاء حساب جديد
                                </label>
                            </div>
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" name="optradio"><span class="block">التسجيل</span>
                                        إنشاء حساب دائم واستخدامه في إتمام الشراء
                                </label>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" id="usr" placeholder="البريد الإلكترونى">
                            </div>
                            <div class="form-group mt-5 mb-5">
                                <button class="second-button hvr-shadow-radial">الدفع كزائر</button>
                            </div>
                        </div>
                        <div class="col-sm-6">
                        <div class="buy-head"><span>عميل دائم</span></div>
                            
                                <div class="form-group">
                                <input type="text" placeholder="البريد الإلكترونى">
                                </div>
                                <div class="form-group">
                                <input type="password" placeholder="كلمة المرور">
                                </div>
                                <div class="form-group">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input" value="">ذكرنى دائما
                                </label>
                                <a href="#"  class="float-left hvr-float-shadow">نسيت؟</a>
                                </div>
                                <div class="form-group mt-5">
                                    <button class="btn second-button hvr-glow">دخول</button>
                                </div>
                            
                            </div>   
                        </div>
                  </div>
                <div class="buy-form right">
                    <h6><span>2</span>عنوان الدفع والشحن</h6>
                        <div class="form-group  specialwidth">
                            <input type="text" placeholder="الاسم الاول">
                        </div>
                        <div class="form-group  specialwidth">
                            <input type="text" placeholder="اسم العائلة">
                        </div>
                        <div class="form-group form-group2">
                            <input type="email" placeholder="الايميل">
                        </div>
                        <div class="form-group form-group2">
                            <input type="number" placeholder="الجوال">
                        </div>
                        <div class="form-group form-group2">
                            <input type="text" placeholder="العنوان">
                        </div>
                        <div class="form-group specialwidth select-div">
                            <select class="form-control" id="sel1">
                                <option selected disabled> أختر الدولة</option>
                                <option>2</option>
                            </select>
                        </div>
                        <div class="form-group specialwidth select-div">
                            <select class="form-control" id="sel1">
                                <option selected disabled>أختر المحافظة</option>
                                <option>2</option>
                            </select>
                        </div>
                        <div class="form-group mt-5">
                            <button class="btn second-button hvr-glow">استمرار</button>
                        </div>
                </div>
                <div class="buy-form right">
                    <h6><span>3</span>خيار الدفع</h6>
                        <!-- radiobutton -->
                    <div class="form-check mr-3 mt-5">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="cahe">الدفع عند الاستلام
                        </label>
                    </div>
                    <div class="form-check mr-3">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="cahe">التحويل البنكى
                        </label>
                    </div>
                    <div class="form-check mr-3">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="cahe">بطاقة الإئتمان 
                        </label>
                    </div>

                            <!-- checkbox -->
                    <div class="form-check mr-3 form-group mt-5">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input" value="">الموافقة علي الشروط والاحكام 
                        </label>
                    </div>
                    <div class="form-check mr-3 form-group">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input" value="">للإشتراك في القائمة البريدية 
                        </label>
                    </div>
                                
                                <!-- button -->
                    <div class="form-group mt-5 mr-3">
                        <button class="btn second-button hvr-glow">ارسال الطلب</button>
                    </div>
                </div>
            </form>  
          </div>
          <div class="col-lg-4">
             <div class="check-out">
                <h6>الكمية :<span>2</span></h6>
                <h6>المبلغ الكلى :<span>200</span></h6>
                <h6>المبلغ بعد الخصم :<span>180</span></h6>
                <hr>
                <h5 class="text">المجموع الكلى :<span>180 ر.س</span></h5>
            </div>
          </div>   
    </div>
  </div>
</div>














<div class="contact">
    <?php
    include 'carousle.php';
    ?>

</div>
<?php
include 'footer.php';
?>
