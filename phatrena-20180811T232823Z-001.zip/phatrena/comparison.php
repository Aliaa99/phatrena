  
  <?php
include 'header.php';
?>

<div class="main-header">
    <div class="phatrena-buy">
        <div class="products-head">
           <div>
                <h1 class="animated bounceInDown sizeless">الرئيسية</h1>
                <h5 class="animated bounceInDown sizemore"> المقارنة</h5>
           </div>
       </div>
    </div>
</div>

<div class="comparison-table my-5 text"> 
    <div class="container">
        <table class="table table-bordered table-sm ">
            <thead>
            <tr>
                <th></th>
                <th class="text py-3">حامل شموع عصرى</th>
                <th class="text py-3">حامل شموع عصرى</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>الصور</td>
                <td><img src="images/product1.png" alt=""></td>
                <td><img src="images/product1.png" alt=""></td>
            </tr>
            <tr>
                <td>السعر</td>
                <td>80.00 ريال</td>
                <td>80.00 ريال</td>
            </tr>
            <tr>
                <td>التقييم</td>
                <td>4نجوم</td>
                <td>4نجوم</td>
            </tr>
            <tr>
                <td>الماركة</td>
                <td>فترينه</td>
                <td>فترينه</td>
            </tr>
            <tr>
                <td></td>
                <td>أضف إلى السله <a href="#"><i class="fas fa-times "></i></a></td>
                <td>أضف إلى السله <a href="#"><i class="fas fa-times "></i></a></td>
            </tr>

            </tbody>
        </table>
    </div>
</div>
<?php
include 'carousle.php';
?>


<?php
include 'footer.php';
?>
