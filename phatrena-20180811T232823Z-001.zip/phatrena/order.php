  
  <?php
include 'header.php';
?>

<div class="main-header">
    <div class="phatrena-buy">
        <div class="products-head">
           <div>
                <h1 class="animated bounceInDown sizeless">الرئيسية</h1>
                <h5 class="animated bounceInDown sizemore"> طلباتى</h5>
           </div>
       </div>
    </div>
</div>

<div class="comparison-table my-5 text"> 
    <div class="container">
        <table class="table table-bordered table-sm ">
            <thead>
                <tr>
                    <th>#</th>
                    <th class="text py-3">العميل </th>
                    <th class="text py-3"> المنتجات</th>
                    <th class="text py-3"> حالة الطلب</th>
                    <th class="text py-3"> السعر الإجمالى</th>
                    <th class="text py-3"> التاريخ</th>
                    <th class="text py-3"> </th>
                </tr>
            </thead>
            <tbody>
            <tr>
                <td>1</td>
                <td>محمد على</td>
                <td>1</td>
                <td>فى المراجعة</td>
                <td>350 ر.س</td>
                <td>15/5/2015</td>
                <td><a href="#"><i class="far fa-eye eyestyle"></i></a></td>
            </tr>

            </tbody>
        </table>
    </div>
</div>
<?php
include 'carousle.php';
?>


<?php
include 'footer.php';
?>
