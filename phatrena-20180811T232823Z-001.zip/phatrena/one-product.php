<?php
include 'header.php';
?>

<div class="main-header">
    <div class="phatrena-buy">
        <div class="products-head">
           <div>
                <h1 class="animated bounceInDown sizeless">المنتجات</h1>
                <h5 class="animated bounceInDown sizemore"> حامل شموع عصرى</h5>
           </div>
       </div>
    </div>
</div>
 <!-- product-details -->
<div class="product-details">
  <div class="container">
    <div class="row">
       <div class="col-lg-5 mb-3">
                <div class="product-img">
                   <img src="images\product1.png">
                </div>
                <div class="images owl-carousel owl-theme">
                    <div class="item">
                        <a  class="active"><img src="images\product1.png"></a>
                    </div>
                    <div class="item">
                        <a ><img src="images\product2.png"></a>
                    </div>
                    <div class="item">
                        <a ><img src="images\layer.png"></a>
                    </div>
                    <div class="item">
                        <a ><img src="images\product1.png"></a>
                    </div>
                </div>
       </div>    
       <div class="col-lg-7">
          <div class="product">
            <h4>حامل شموع عصرى إضافة لمسة شخصية</h4>
            <a href="#"><i class="far fa-star"></i></a>
            <a href="#"><i class="far fa-star"></i></a>
            <a href="#"><i class="far fa-star"></i></a>
            <a href="#"><i class="far fa-star"></i></a>
            <a href="#"><i class="far fa-star"></i></a>

            <span>أضف تقييم</span>
            <h2>80 ر.س </h2>
            <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي 
            القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها .</p>
            <div class="crease-decrease">
               <div class="row">
                  <div class="col-sm-4">
                     <div class="button-to-increase">
                        <a class="plus-button float-right pp" >
                            <i class="fas fa-plus"></i>
                        </a>

                        <input type="text" placeholder="0" class="cc">

                        <a class="minus-button float-left mm" >
                           <i class="fas fa-minus"></i>
                        </a>
                    </div>
                  </div>
                  <div class="col-sm-4 col-xs-6 ">
                    <a href="#" class="text-danger hvr-hang"><span>أضف إلى السلة</span></a>
                  </div>
                  <div class="col-sm-4 col-xs-6 ">
                    <a href="#" class="text-body hvr-shrink" ><span>أضف للمقارنة</span></a>
                  </div>
               </div>
            </div>

            <div class="social-media">
               <h6>شارك المنتج</h6>
               <a href="#" class="share hvr-float"><i class="fas fa-share-alt"></i></a>
               <a href="#" class="comment hvr-float"><i class="fas fa-comment-alt"></i></a>
               <a href="#" class="message hvr-float"><i class="fas fa-envelope"></i></a>
               <a href="#" class="pin hvr-float"><i class="fab fa-pinterest-p"></i></a>
               <a href="#" class="twitter hvr-float"><i class="fab fa-twitter"></i></a>
               <a href="#" class="facebook hvr-float"><i class="fab fa-facebook-f"></i></a>

            </div>

          </div>
       </div>        
    </div> 

    <div class="product-options">
       <button class="btn red-button hvr-float-shadow">المواصفات</button>
       <button class="btn second-button hvr-float-shadow" >التقييمات</button>
       <p>حامل شموع  من الأسمنت علي شكل فراشة و ملون بألوان أكريلك و معه شمعه يمكن تغييرها   </p>
    </div>  
  </div>   
</div>

<?php
include 'contact2.php';
?>
<?php
include 'footer.php';
?>
