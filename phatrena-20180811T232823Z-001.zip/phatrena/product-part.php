    <!-- واجهة عرض -->    
<div class="product">
    <div class="container">
        <div class="row">

            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="product-detials hvr-float">
                    <div class="image-details ">
                       <img src="images\product1.png" alt="">
                    </div>
                    <div class="rate-details">
                        <div class="rate">
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                        </div>
                        <h5>حامل شموع عصرية</h5>
                        <h5>إضافة لمسة شخصية</h5>
                        <h6 class="price-pro">
                           <span >150 ر.س</span>
                           <a href="#">إضافة للسله</a>
                        </h6>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="product-detials  hvr-float">
                    <div class="image-details">
                       <img src="images\product2.png" alt="">
                    </div>
                    <div class="rate-details">
                        <div class="rate">
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                        </div>
                        <h5>حامل شموع عصرية</h5>
                        <h5>إضافة لمسة شخصية</h5>
                        <h6 class="price-pro">
                           <span>150 ر.س</span>
                           <a href="#">إضافة للسله</a>
                        </h6>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
