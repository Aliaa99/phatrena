<?php
include 'header.php';
?>

<div class="main-header">
    <div class="phatrena-buy">
        <div class="products-head">
           <div>
                <h1 class="animated bounceInDown sizeless">الرئيسية</h1>
                <h5 class="animated bounceInDown sizemore">سلة الشراء</h5>
           </div>
       </div>
    </div>
</div>

<div class="cart mt-5">
   <div class="container">
      <div class="row">
          <div class="col-lg-8">
            <div class="product-details-div">
                <div class="row">
                    <div class="col-sm-2">
                        <img src="images\product1.png" alt="">
                    </div>     
                    <div class="col-sm-4">
                        <div class="words">
                            <h6>حامل شموع عصرى</h6>
                            <span>150 ر.س</span>
                        
                            <div class="rate-details">
                                <div class="rate">
                                    <span>
                                    <a href="#">
                                            <i class="far fa-star"></i>
                                    </a>
                                    </span>
                                    <span>
                                    <a href="#">
                                            <i class="far fa-star"></i>
                                    </a>
                                    </span>
                                    <span>
                                    <a href="#">
                                            <i class="far fa-star"></i>
                                    </a>
                                    </span>
                                    <span>
                                    <a href="#">
                                            <i class="far fa-star"></i>
                                    </a>
                                    </span>
                                    <span>
                                    <a href="#">
                                            <i class="far fa-star"></i>
                                    </a>
                                    </span>
                                </div>
                            </div>
                        </div>  
                    </div>   
                    <div class="col-sm-4">
                        <div class="button-to-increase mt-4">
                            <a class="plus-button float-right pp" >
                                <i class="fas fa-plus"></i>
                            </a>

                            <input type="text" placeholder="0" class="cc">

                            <a class="minus-button float-left mm" >
                            <i class="fas fa-minus"></i>
                            </a>
                        </div>
                    </div>     
                    <div class="col-sm-2">
                        <a href="#" class="times hvr-float-shadow mt-3"><i class="fas fa-times"></i></a>
                        <a href="#" class="edit hvr-float-shadow"><i class="fas fa-pencil-alt"></i></a>
                    </div>              
                </div>     
            </div>  
            <div class="check-out">
                <h6>الكمية :<span>2</span></h6>
                <h6>المبلغ الكلى :<span>200</span></h6>
                <h6>المبلغ بعد الخصم :<span>180</span></h6>
                <hr>
                <h5 class="text">المجموع الكلى :<span>180 ر.س</span></h5>
            </div>
            <div class="checkout-button">
               <button class="second-button hvr-shadow-radial">اتمام الشراء</button>
            </div>
          </div> 
        <div class="col-lg-4">
          <div class="product-detials  hvr-float">
                    <div class="image-details">
                       <img src="images\product2.png" alt="">
                    </div>
                    <div class="rate-details">
                        <div class="rate">
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                            <span>
                               <a href="#">
                                    <i class="far fa-star"></i>
                               </a>
                            </span>
                        </div>
                        <h5>حامل شموع عصرية</h5>
                        <h6>
                           <span>150 ر.س</span>
                        </h6>
                    </div>
                </div>

        </div>           
      </div>   
  </div>
</div>

<div class="contact">
    <?php
    include 'carousle.php';
    ?>

</div>
<?php
include 'footer.php';
?>
