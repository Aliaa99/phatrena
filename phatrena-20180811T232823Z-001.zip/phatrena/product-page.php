<?php
include 'header.php';
?>

<div class="main-header">
    <div class="phatrena-buy">
        <div class="products-head">
           <div>
                <h1 class="animated bounceInDown">المنتجات</h1>
           </div>
       </div>
    </div>
</div>

 <!-- ترتيب بالبحث -->
<div class="attratment">
    <div class="container">
        <div class="row">
            <div class="col-sm-9 mb-3">
                <span>ترتيب بحسب</span>
                <div class="form-group">
                    <select class="form-control" id="sel1">
                        <option>المنتجات الأحدث</option>
                        <option>المنتجات الأحدث</option>
                        <option>المنتجات الأحدث</option>
                    </select>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="icons">
                    <a href="#" class="link-list"><i class="flaticon-list"></i></a>
                    <a href="#" class="link-menu"><i class="flaticon-menu"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include 'product-part.php';
?>
<div class="backcolor">
    <?php
    include 'contact-info.php';
    ?>
</div>
<?php
include 'carousle.php';
?>

<?php
include 'footer.php';
?>
