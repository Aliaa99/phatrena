  
  <?php
include 'header.php';
?>

<div class="main-header">
    <div class="phatrena-buy">
        <div class="products-head">
           <div>
                <h1 class="animated bounceInDown sizeless">الرئيسية</h1>
                <h5 class="animated bounceInDown sizemore"> طلباتى</h5>
           </div>
       </div>
    </div>
</div>

<div class="comparison-table mt-5 "> 
    <div class="container">
        <table class="table table-bordered table-sm text">
            <thead>
                <tr>
                    <th>#</th>
                    <th class="text py-3">العميل </th>
                    <th class="text py-3"> المنتجات</th>
                    <th class="text py-3"> حالة الطلب</th>
                    <th class="text py-3"> السعر الإجمالى</th>
                    <th class="text py-3"> التاريخ</th>
                    <th class="text py-3"> </th>
                </tr>
            </thead>
            <tbody>
            <tr>
                <td>1</td>
                <td>محمد على</td>
                <td>1</td>
                <td>فى المراجعة</td>
                <td>350 ر.س</td>
                <td>15/5/2015</td>
                <td><a href="#"><i class="far fa-eye eyestyle"></i></a></td>
            </tr>

            </tbody>
        </table>
    </div>
    <div class="backcolor py-3 mt-5">
    <div class="container">
    <div class="row ">
           <div class="col-sm-6 right">
           <h5 class="redcolor  family mb-3 right">معلومات العميل</h5>
               <div class="col-xs-6">
                   <h6 class="ml-3 py-2 redcolor">الاسم</h6>
                    <h6 class="ml-3 py-2 redcolor">البريد الالكترونى</h6>
                    <h6 class="ml-3 py-2 redcolor">رقم الجوال</h6>
                    <h6 class="ml-3 py-2 redcolor">الدولة</h6>
                    <h6 class="ml-3 py-2 redcolor">المدينة</h6>
               </div>
               <div class="col-xs-6">
                    <h6 class="py-2"> محمد على</h6>
                    <h6 class="py-2">ali@ss.com</h6>
                    <h6 class="py-2">+665845987</h6>
                    <h6 class="py-2">السعودية</h6>
                    <h6 class="py-2">الرياض</h6>
               </div>
           </div>
           <div class="col-sm-6 right">
           <h5 class="redcolor family mb-3 right">عنوان الشحن</h5>
               <h6 class="py-2">السعودية</h6>
               <h6 class="py-2">الرياض</h6>
               <h6 class="py-2">شارع ناهى السعيد</h6>
               <h6 class="py-2">الطابق الثانى</h6>
           </div>
        </div>
</div>
</div>
</div>
<?php
include 'carousle.php';
?>


<?php
include 'footer.php';
?>
