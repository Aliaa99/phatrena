<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>phatrena</title>
    <link rel="stylesheet" href="css/bootstrap4.css">
    <link rel="stylesheet" href="css/bootstrap4rtl.css">
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/hover-min.css">
    <link rel="stylesheet" href="css/stylesheet1.css">
    <link rel="stylesheet" href="css/stylesheet.css">
    <link rel="shortcut icon" href="images/logo.png">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
<div class="main-haeder">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 col-md-2">
                <div class="logo-img">
                    <img src="images/logo.png" alt="">
                </div>
            </div>
            <div class="col-lg-7 col-lg-offset-1 col-md-8 col-md-offset-1">
                <ul class="nav list">
                    <li class="nav-item active">
                       <a class="nav-link text-body" href="index.php">الرئيسية</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link text-body" href="#">المتجر</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link text-body" href="profile.php">حسابى</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link text-body" href="#">تتبع الطلبات</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link text-body" href="#">طلب خاص</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link text-body" href="#">ساعات العمل</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link text-body" href="#">المزيد</a>
                    </li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-2">
                <div class="list">
                    <div class="left-links">
                        <a href="#" class="cart2">
                          <i class="fas fa-shopping-cart"></i>
                          <span>(2)</span>
                        </a>
                         <!-- when click -->
                        <div class="basket-hover animated zoomIn">
                            <ul class="p-0">
                                <li class="p-3">
                                   <i class="fas fa-times"></i>
                                    <img  src="images/logo.png">
                                    <span>أسم المنتج</span>
                                    <span> 1258 </span>
                                </li>
                            </ul>
                            <div class="basket-links">
                                <a href="#">عرض السلة</a>
                                <a href="#">توجة الكاشير</a>
                            </div>
                        </div>  
                          <!-- search  -->
                        <a href="#"  data-toggle="collapse" data-target="#demo">
                          <i class="fas fa-search"></i>
                         </a>
                         <div id="demo" class="collapse">
                             <input type="text" placeholder="أبحث">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- side menu-->
<div class="side-menu">
    <div class="container">
       <div class="side-menu-header">
          <a href="#side-list" class="open-menu">
             <i class="fas fa-align-justify"></i>
          </a>
          <a href="#" class="logo-img">
            <img src="images/logo.png">
          </a>
        </div>
        <div class="menu2 animated fadeInRight" id="side-list">
            <a href="#side-list" class="close-menu">
              <i class="fa fa-times" aria-hidden="true"></i>
            </a>
             <ul>
                    <li class="nav-item active">
                       <a class="nav-link" href="#">الرئيسية</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="#">المتجر</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="#">حسابى</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="#">تتبع الطلبات</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="#">طلب خاص</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="#">ساعات العمل</a>
                    </li>
                    <li class="nav-item">
                       <a class="nav-link" href="#">المزيد</a>
                    </li>
                    <li>
                       <a href="#" class="cart2">
                          <i class="fas fa-shopping-cart"></i>
                          <span>(2)</span>
                        </a>
                        <!-- when click -->
                        <div class="basket-hover">
                            <ul class="p-0">
                                <li class="p-3">
                                   <i class="fas fa-times"></i>
                                    <img  src="images/logo.png">
                                    <span>أسم المنتج</span>
                                    <span> 1258 </span>
                                </li>
                            </ul>
                            <div class="basket-links">
                                <a href="#">عرض السلة</a>
                                <a href="#">توجة الكاشير</a>
                            </div>
                        </div>  

                    </li>
                    <li>
                        <a href="#" data-toggle="collapse" data-target="#demo2">
                          <i class="fas fa-search"></i>
                         </a>
                         <div id="demo2" class="collapse">
                             <input type="text" placeholder="أبحث">
                        </div>

                    </li>
             </ul>
        </div>

    </div>
</div>
</header>
