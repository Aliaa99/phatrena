<?php
include 'header.php';
?>

<div class="main-header">
    <div class="phatrena-buy">
        <div class="products-head">
           <div>
                <h1 class="animated bounceInDown sizeless">الرئيسية</h1>
                <h5 class="animated bounceInDown sizemore"> تواصل معنا</h5>
           </div>
       </div>
    </div>
</div>

<?php
include 'contact-info.php';
?>


<div class="forms mb-5">
        <div class="container">
            <div class="row">
            
                <div class="col-md-6">
                    <div class="red-box">
                        <p>إذا كنت ترغب فى اى مساعدة يمكنك ارسال رسالة لنا الان وسوف نتواصل معك فى اقرب وقت ممكن</p>
                    </div>
                </div>

                <div class="col-md-6">
                    <form>
                    <div class="form-group">
                        <input type="text" placeholder="الاسم">
                    </div>
                    <div class="form-group">
                        <input type="email" placeholder="البريد الإلكترونى">
                    </div>
                    <div class="form-group">
                        <textarea name="" id="" rows="6" class="complet-width" placeholder="lkl">
                            
                        </textarea>
                    </div>
                    <div class="form-group mt-5">
                        <button class="btn second-button hvr-glow">ارسال</button>
                    </div>
                    </form>
                </div>
             </div>
         </div>
    </div>

<?php
include 'carousle.php';
?>


<?php
include 'footer.php';
?>
