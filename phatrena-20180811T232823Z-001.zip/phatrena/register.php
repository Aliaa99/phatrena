<?php
include 'header.php';
?>

<div class="main-header">
    <div class="phatrena-buy">
        <div class="products-head">
           <div>
                <h1 class="animated bounceInDown sizeless">الرئيسية</h1>
                <h5 class="animated bounceInDown sizemore">التسجيل</h5>
           </div>
       </div>
    </div>
</div>



<div class="contact margin-top">
<div class="forms transform margin-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <form>
                <div class="form-group">
                   <input type="text" placeholder="الأسم">
                </div>
                <div class="form-group">
                   <input type="text" placeholder="البريد الإلكترونى">
                </div>
                <div class="form-group">
                   <input type="password" placeholder="كلمة المرور">
                </div>
                <div class="form-group">
                   <input type="password" placeholder="تأكيد كلمة المرور">
                </div>
                <div class="form-group">
                   <input type="text" placeholder="رقم الجوال">
                </div>
                <div class="form-group mt-5">
                    <button class="btn second-button hvr-glow">تسجيل</button>
                </div>
                </form>
            </div>

            <div class="col-md-6">
                <div class="red-box">
                    <p>إذا كنت تمتلك حسابا، قم بالدخول معنا الان و استمتع بمنتجاتنا و عروضنا الحصرية.</p>
                    <button class="btn second-button hvr-shadow-radial">دخول الآن </button>
                </div>
            </div>
  

        </div>
    </div>
</div>

    <?php
    include 'carousle.php';
    ?>
</div>
<?php
include 'footer.php';
?>
