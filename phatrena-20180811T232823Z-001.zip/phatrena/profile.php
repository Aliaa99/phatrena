  <?php
include 'header.php';
?>

<div class="main-header">
    <div class="phatrena-buy">
        <div class="products-head">
           <div>
                <h1 class="animated bounceInDown sizeless">الرئيسية</h1>
                <h5 class="animated bounceInDown sizemore"> حسابى</h5>
           </div>
       </div>
    </div>
</div>

<div class="backcolor">
   <div class="container">
        <div class="row">
          <div class="col-sm-4 mt-5 comparison-table">
             <h6 class="pt-3 "><a href="#" class="redcolor">الحساب</a></h6>
             <h6 class="pt-3 "><a href="#">كلمة المرور</a></h6>
             <h6 class="pt-3 "><a href="#">طلباتى</a></h6>
          </div>
           <div class="col-sm-8">
            <div class="forms mb-5">
                <form>
                   <div class="form-group">
                        <input type="text" placeholder="الأسم">
                    </div>
                    <div class="form-group">
                        <input type="email" placeholder="البريد الإلكترونى">
                    </div>
                    <div class="form-group">
                        <input type="number" placeholder="رقم الجوال">
                    </div>
                    <div class="form-group">
                       <input type="password" placeholder="كلمة المرور">
                    </div>
                    <div class="form-group mt-5">
                        <button class="btn second-button hvr-glow">حفظ</button>
                    </div>
                </form>
            </div>
          </div>
       </div>
   </div>
</div>



<?php
include 'carousle.php';
?>


<?php
include 'footer.php';
?>
