  <?php
include 'header.php';
?>

<div class="main-header">
    <div class="phatrena-buy">
        <div class="products-head">
           <div>
                <h1 class="animated bounceInDown sizeless">الرئيسية</h1>
                <h5 class="animated bounceInDown sizemore"> نتائج البحث</h5>
           </div>
       </div>
    </div>
</div>

    <div class="comparison-table mt-5">
        <div class="container">
            <h6 class="right my-3">نتائج عن<span class="redcolor">(شموع)</span> وجد<span class="redcolor">(3)</span></h6>
        </div>
    </div>
    <?php
    include 'product-part.php';
    ?>
</div>

<?php
include 'carousle.php';
?>


<?php
include 'footer.php';
?>
