<?php
include 'header.php';
?>
<div class="main-carousle-details">
    <!-- main owl-carousle -->
    <div class="main-carousle owl-carousel owl-theme">
        <div class="item">
        <img src="images\layer.png"alt="">
        </div>
        <div class="item">
        <img src="images\layer.png"alt="">
        </div>
        <div class="item">
        <img src="images\layer.png"alt="">
        </div>
    </div>
    <div class="head-phatrena-buy">
    <div class="phatrena-buy">
        <div>
           <div>
                <h1 class="animated bounceInDown">فترينه</h1>
                <h5 class="animated bounceInRight">بتفاصيل جديده لك ولمنزل جديد</h5>
                <a href="#" class="second-button hvr-curl-top-right animated bounceInLeft">أشترى الآن</a>
           </div>
       </div>
    </div>
    </div>
</div>
    <!-- واجهة عرض -->    
<div class="show-example">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <div class="show-detials">
                    <h2>واجهة عرض</h2>
                    <h4>لكل ما هو جديد وحديث</h4>
                    <a href="#" class="second-button hvr-shadow-radial">من نحن</a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="show-img1">
                    <img src="images\show1.png">
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="show-img2 mt-2">
                    <img src="images\show2.png">
                </div>
            </div>
        </div>
    </div>
</div> 
    <!-- واجهة عرض -->    
<div class="buy-now">
    <div class="container">
    <div class="row">
        <div class="col-xs-12">
        <div class="detals">
            <p>مع فترينه تسوق بكل ثقة، بتشكيلة واسعة وفاخرة من الإكسسوارات والمنتجات الشخصية ، والديكورات العصرية . التي تُضيف لك ولمنزلك لمسات جمالية بكل أناقة.</p>
            <a href="#" class="second-button hvr-glow">أشترى الآن</a>
        </div>
        </div>
        </div>
    </div>
</div>
    <?php
    include 'product-part.php';
    ?>
<div class="backcolor">
    <?php
    include 'contact-info.php';
    ?>
</div>
<?php
include 'carousle.php';
?>

<?php
include 'footer.php';
?>
