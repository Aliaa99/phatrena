

<footer class="p-5">
   <div class="container">
    <div class="footer-logo pb-5">
        <img src="images\logo.png" alt="">
    </div>
    <div class="footer-form pb-5">
        <form> 
           <input type="text" placeholder="البريد الالكترونى">
           <button class="second-button hvr-shadow-radial">أشترك</button>
        </form>
    </div>
    <p>أنت تبحث دائماً عن التجديد في كل شيء، ومن الطبيعي أن يكون اهتمامك منصبّاً على ظهورك بالشكل اللائق، الذي يُرضيك ويجعلك تحوز إعجاب وثقة الآخرين. </p>
    <div class="footer-links">
        <a href="#">
           <i class="fab fa-snapchat-ghost"></i>
        </a>
        <a href="#">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="#">
            <i class="fab fa-twitter"></i>
        </a>
    </div>
    <h5>جميع الحقوق محفوظه لفترينة 2018</h5>
   </div>
</footer>
 <!-- serach page -->
<div class="search-page animated ZoomIn">
    <div class="container">
        <div class="input-search">
            <form>
                <div class="form-group">
                    <input type="text" placeholder="أبحث عن منتج" class="p-3">
                </div>
                <button class="btn ">
                    <i class="fas fa-search"></i>
                </button>
            </form>
        </div>
            <a href="#">
                <i class="fas fa-times"></i>
            </a>
    </div>
</div>


<script src="js\jquery.js"></script>
<script src="js\popper.js"></script>
<script src="js\bootstrap4.js"></script>
<script src="js\owl.carousel.min.js"></script>
<script src="js\main.js"></script>
</body>
</html>