    <!-- اتصل بنا -->    
<div class="contact">
    <div class="container">
        <h2>دعنا على اتصال:</h2>
        <div class="row pb-5">
            <div class="col-sm-4">
                <h6>العنوان</h6>
                <h6>وصف كامل للعنوان</h6>
            </div>
            <div class="col-sm-4">
                <h6>الهاتف</h6>
                <h6>69452478547874 </h6>
            </div>
            <div class="col-sm-4">
                <div class="work-time border border-dark p-4">
                    <h6>ساعات العمل</h6>
                    <h6>يوميا,من 8مساء الى 10مساء</h6>
                </div>
            </div>
        </div>
    </div>
    <?php
    include 'carousle.php';
    ?>
</div>