
$(document).ready(function(){
    $('.open-menu').click(function(){
        $('.menu2').css({"width":"60%",})
        $('.side-menu-header').css({"left":"40%",})
        $(this).toggle();
        $('.side-menu-headerspan').toggle();

    });
    $('.close-menu').click(function(){
        $(this).parent().css({"width":"0",})
        $('.side-menu-header').css({"left":"0",})
        $('.open-menu').toggle();
        $('.side-menu-header span').toggle();
    });

    //main  owl-carousle
    $('.main-carousle.owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        rtl:true,
        nav:true,
        dots:false,
        autoplay:true,
        autoplayTimeout:3000,
        navText:["",""],
        responsive:{
            0:{
                items:1
            }
        }
    })
    // rate
    $('.price-pro ').hover(function(){
        $(this).children().toggle(3000);
    });

    //product  owl-carousle
    $('.product-carousel.owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        rtl:true,
        nav:false,
        dots:false,
        autoplay:true,
        autoplayTimeout:3000,
        stagePadding:99,
        responsive:{
            0:{
                items:1
            },
            800:{
                items:3
            },
            1000:{
                items:4
            }
    
        }
    })

    $(".cart2").click(function(){
        $(".basket-hover").toggle().fadeIn(300).delay(3000);
    });    

// images of products
$('.images.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    rtl:true,
    nav:false,
    dots:false,
    responsive:{
        0:{
            items:2
        },
        400:{
            items:2
        },
        600:{
            items:3
        },
        1100:{
            items:4
        }
    }
})
// images in product
$(".product-details .images .item a img").click(function(){
    $smalimg=$(this).attr('src');
    $(".product-details .product-img img").attr("src", $smalimg);
});    

    $('.pp').click(function(){
        var x=$(this).parent().find(".cc").val()
           x++;
        $(this).parent().find(".cc").val(x)
    });

    $('.mm').click(function(){
        var x=$(this).parent().find(".cc").val()
          if(x>1){
         x--;
        }
       $(this).parent().find(".cc").val(x)
    });

});
// $(".search-button").click(function(){
//     $(".search-page").css('display','block');
// });    
// $(".search-page a").click(function(){
//     $('.search-page').css('display','none');
// });    












